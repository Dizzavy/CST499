</div> <!-- /container -->
<footer class="container text-center" style="margin-top:20px;">
  <p class="text-muted">CST499 Student System &copy; <?=date('Y')?></p>
</footer>
</body>
</html>
